-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2024 at 12:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photonix`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `pay_id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `O_id` int(11) NOT NULL,
  `P_id` int(11) NOT NULL,
  `C_name` varchar(25) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `Price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`pay_id`, `invoice_no`, `O_id`, `P_id`, `C_name`, `phone`, `Price`, `quantity`, `Total`, `Address`, `Date`) VALUES
(1, 86923, 1, 1, 'Adarsh', 9061659939, 599, 5, 2995, 'muvattupuzha', '2023-12-14'),
(2, 91434, 2, 4, 'Aswin C.S', 9567191205, 649, 2, 1298, 'Ernakulam', '2023-12-14'),
(3, 67072, 3, 2, 'Ann Christine', 7025889751, 799, 4, 3196, 'Thrissur', '2023-12-17'),
(4, 93781, 4, 3, 'Ann Christine', 7025889751, 1099, 4, 4396, 'muvattupuzha', '2023-12-18'),
(5, 53821, 5, 1, 'Ann Christine', 7025889751, 599, 2, 1198, 'Ernakulam', '2023-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Catid` int(11) NOT NULL,
  `Catname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Catid`, `Catname`) VALUES
(1, 'Plane Frame'),
(2, 'Pattern Frame');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `co_id` int(11) NOT NULL,
  `C_id` int(11) NOT NULL,
  `C_name` varchar(25) NOT NULL,
  `msg` varchar(50) NOT NULL,
  `reply` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`co_id`, `C_id`, `C_name`, `msg`, `reply`) VALUES
(1, 2, 'Aswin C.S', 'Quality??', 'its good quality');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Cid` int(11) NOT NULL,
  `Cname` varchar(15) NOT NULL,
  `Cadrs` varchar(25) NOT NULL,
  `Cphone` bigint(20) NOT NULL,
  `Cpswd` varchar(15) NOT NULL,
  `Ccpswd` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cid`, `Cname`, `Cadrs`, `Cphone`, `Cpswd`, `Ccpswd`) VALUES
(1, 'Hemanth', 'Thodupuzha', 9061532907, 'Hemanth@2001', 'Hemanth@2001'),
(2, 'Aswin C.S', 'Vaikom', 9567191205, 'Aswin@2000', 'Aswin@2000'),
(3, 'Anandu', 'Kunjithanny', 6238386620, 'Anandu@2000', 'Anandu@2000'),
(4, 'Suraj', 'kannur', 9495767186, 'Suraj@2001', 'Suraj@2001'),
(5, 'Adarsh', 'Idukky', 9061659939, 'Adarsh@2001', 'Adarsh@2001'),
(7, 'Ann Christine', 'Kannur', 7025889751, 'ann', 'ann'),
(8, 'Stejim', 'Palavayal', 9087654327, '123', '123'),
(9, 'Jubin', 'Cherunilathu', 7025889751, '123', '123'),
(10, 'Jubin', 'Cherunilathu', 7025889751, 'jubin@2001', 'jubin@2001'),
(11, 'Jubin philip', 'Cherunilathu', 7025889751, '1234', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(11) NOT NULL,
  `Cid` int(11) NOT NULL,
  `C_name` varchar(20) NOT NULL,
  `P_id` int(11) NOT NULL,
  `feedback` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `Cid`, `C_name`, `P_id`, `feedback`) VALUES
(1, 2, 'Aswin C.S', 4, 'Good Product');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `O_id` int(11) NOT NULL,
  `C_id` int(11) NOT NULL,
  `P_id` int(11) NOT NULL,
  `U_image` varchar(255) NOT NULL,
  `P_price` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `U_des` varchar(30) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Status` varchar(25) NOT NULL,
  `Payment` varchar(20) DEFAULT NULL,
  `Total` int(11) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`O_id`, `C_id`, `P_id`, `U_image`, `P_price`, `quantity`, `U_des`, `Address`, `Status`, `Payment`, `Total`, `Date`) VALUES
(1, 5, 1, 'IMG_7204.JPG', '599', 5, 'Friends Forever', 'muvattupuzha', 'Accepted', 'Wallet/Postpaid', 2995, '2023-12-14'),
(2, 2, 4, 'IMG_7155.JPG', '649', 2, 'Rock', 'Ernakulam', 'Accepted', 'Card', 1298, '2023-12-14'),
(3, 7, 2, 'Screenshot_20231112-134206_Instagram.png', '799', 4, 'Ridhin ', 'Thrissur', 'Accepted', 'Card', 3196, '2023-12-17'),
(4, 7, 3, 'wp7676304-2022-ford-mustang-gt-wallpapers.jpg', '1099', 4, 'Ready to Race', 'muvattupuzha', 'Waiting', 'Net Banking', 4396, '2023-12-18'),
(5, 7, 1, 'Screenshot_20231209-001742_Flipkart.png', '599', 2, 'Puma Rebound', 'Ernakulam', 'Accepted', 'Wallet/Postpaid', 1198, '2023-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `P_id` int(11) NOT NULL,
  `P_name` varchar(25) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `P_des` varchar(100) NOT NULL,
  `P_Color` varchar(15) NOT NULL,
  `P_image` varchar(255) NOT NULL,
  `P_dim` varchar(15) NOT NULL,
  `P_Price` float NOT NULL,
  `P_Stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`P_id`, `P_name`, `cat_id`, `P_des`, `P_Color`, `P_image`, `P_dim`, `P_Price`, `P_Stock`) VALUES
(1, 'Plane Frame', 1, 'Square Frame With Wooden Finish', 'golden white', 'pl (1).jpeg', '10 x 8', 599, 8),
(2, 'Pattern', 1, 'Frame with Mat Finish.', 'White', 'pl (7).jpeg', '6 x 8', 799, 21),
(3, 'Plane Frame', 1, 'Frame with Black mat finish', 'Black', 'pl (3).jpeg', '15 x 12', 1099, 20),
(4, 'Plane', 2, 'frame with fibre body', 'yellow white', 'pl (12).jpeg', '12 x 10', 649, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Catid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`co_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Cid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`O_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`P_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `co_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `O_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `P_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
